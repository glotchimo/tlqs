import React from 'react'
import FormControl from '@mui/material/FormControl';
import TextField from '@mui/material/TextField';

function ProblemDescription({ studentProblem, setStudentProblem }) {

    const handleChange = (event) => {
        setStudentProblem(event.target.value);
    };

    return (
        <FormControl fullWidth>
            <TextField multiline sx={{ m: 1 }}
                label="Problem"
                placeholder="Where do I begin..."
                rows={14}
                maxRows={14}
                onChange={handleChange}
            />
        </FormControl>
    )
}

export default ProblemDescription