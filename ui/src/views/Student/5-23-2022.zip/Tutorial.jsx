import React from 'react'
import Box from '@mui/material/Box';


function Tutorial() {
    return (
        <Box sx={{ width: '90%', height: '21.5vh', backgroundColor: '#E9E9E9', overflow: 'hidden' }}>
            <Box sx={{ m: 2, fontFamily: 'IBM Plex Sans' }}>
                Here would be a basic tutorial on how to use the student view. The rest beneath this will be filler.
            </Box>
        </Box>
    )
}

export default Tutorial